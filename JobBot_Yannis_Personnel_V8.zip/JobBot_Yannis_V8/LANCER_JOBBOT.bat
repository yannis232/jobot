@echo off
setlocal
cd /d "%~dp0"
title JobBot 8.0.0
echo JobBot - VERSION 8.0.0
echo Ouverture de JobBot dans Opera...
if not exist "runtime\python.exe" (
  echo.
  echo Le dossier est incomplet. Extrais entierement le ZIP de JobBot.
  echo Garde les dossiers runtime, vendor, web et extension a cote de ce fichier.
  pause
  exit /b 1
)
"runtime\python.exe" -u app.py
if errorlevel 1 (
  echo.
  echo JobBot s'est arrete. Le message ci-dessus indique le probleme.
)
pause
